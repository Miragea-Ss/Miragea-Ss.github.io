Eliora Infinite Canvas — Local Kit
Version: 2026-08-06.2 / Git commit 7a98fbe

START
1. Start ComfyUI normally.
2. Double-click START-ELIORA-CANVAS.bat.
3. Your browser opens http://127.0.0.1:8765/infinite-canvas.html
4. Confirm GPU ON / Path ON, then press Comfy送信.

No account or identity verification is required by Eliora.
Local ComfyUI and the Canvas Agent bridge stay on 127.0.0.1.
International BYOK endpoints are optional.

OPTIONAL LOCAL LLM
Start a llama.cpp OpenAI-compatible server on 127.0.0.1:8080.
The canvas remains usable when llama.cpp is offline.

LOCAL AGENT / MCP
The launcher starts the bridge on 127.0.0.1:8190.
At runtime it creates eliora-agent-connection.json with a temporary token.
Keep that file private. It is regenerated when the bridge restarts.
Every Agent write requires visible browser approval and can be undone.

TROUBLESHOOTING
- Do not open infinite-canvas.html with file://. Use the launcher.
- If GPU is OFF, verify ComfyUI at http://127.0.0.1:8188.
- If Path is OFF, close the old bridge window and run the launcher again.
- Python is detected automatically. You may set ELIORA_PY to a Python executable.

SECURITY
- Do not publish eliora-agent-connection.json.
- Do not share API keys, device codes, or generated bridge tokens.
- No China real-name verification service is included or required.

Official site:
https://miragea-ss.github.io/eliora/infinite-canvas.html

Source:
https://github.com/Miragea-Ss/Miragea-Ss.github.io
